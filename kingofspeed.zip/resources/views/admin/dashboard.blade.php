@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('content')
    <div class="container">
        <h2>Admin Dashboard</h2>
        <p>Welcome, Admin!</p>
    </div>
@endsection
